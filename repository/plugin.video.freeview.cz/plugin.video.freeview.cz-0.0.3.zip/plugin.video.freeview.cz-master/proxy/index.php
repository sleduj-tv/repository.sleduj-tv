<html>
	<head>
		<title>kodi tools</title>
	</head>
	<body>
		Skript na ziskanie url streamov bol presunuty na p.6f.sk.<br/>
		Obsluzenych requestov do presunu: <?=file_get_contents("rcount")?><br/><br/>
        Adresa <a href="http://p.xf.cz/r">http://p.xf.cz/r</a> pre skratku na instalaciu repozitara stale funguje, funguje aj <a href="https://p.6f.sk/r">https://p.6f.sk/r</a> a ak nie, pouzite priamo <a href="https://cache-sk.github.io/kodirepo"> https://cache-sk.github.io/kodirepo</a>, kam uz obe skratky smeruju.
	</body>
</html>