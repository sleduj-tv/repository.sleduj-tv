<?
    header('Location: https://cache-sk.github.io/kodirepo');
?>